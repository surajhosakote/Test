package Suraj;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class JavaService

{
	// ---( internal utility methods )---

	final static JavaService _instance = new JavaService();

	static JavaService _newInstance() { return new JavaService(); }

	static JavaService _cast(Object o) { return (JavaService)o; }

	// ---( server methods )---




	public static final void AddInts (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(AddInts)>> ---
		// @sigtype java 3.5
		// [i] field:0:required a
		// [i] field:0:required b
		// [o] field:0:required s
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	a = IDataUtil.getString( pipelineCursor, "a" );
			String	b = IDataUtil.getString( pipelineCursor, "b" );
		pipelineCursor.destroy();
		
		int num1 = Integer.parseInt(a);
		int num2 = Integer.parseInt(b);
		int s = num1+num2;
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "s", s );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void Concat (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(Concat)>> ---
		// @sigtype java 3.5
		// [i] field:0:required Name
		// [i] field:0:required Sname
		// [o] field:0:required Result
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	Name = IDataUtil.getString( pipelineCursor, "Name" );
			String	Sname = IDataUtil.getString( pipelineCursor, "Sname" );
		pipelineCursor.destroy();
		String str=String.valueOf(Name);
		String str1=String.valueOf(Sname);
		
		String Result=str.concat(str1);
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "Result", Result );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void DocumentProcessing (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(DocumentProcessing)>> ---
		// @sigtype java 3.5
		// [i] record:0:required Student
		// [i] - field:0:required Name
		// [i] - field:0:required Roll
		// [o] field:0:required Op
		// --- <<IS-END>> ---

                
	}



	public static final void NumberCheck (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(NumberCheck)>> ---
		// @sigtype java 3.5
		// [i] field:0:required Number
		// [o] field:0:required Result
		// [o] field:0:required Untitled
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	Number = IDataUtil.getString( pipelineCursor, "Number" );
		pipelineCursor.destroy();
		
		int num1=Integer.parseInt(Number);
		String c="Correct";
		String str=String.valueOf(c);
		String d="Wrong";
		String str1=String.valueOf(d);
		if(num1==10)
		{
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "str", str );
			pipelineCursor_1.destroy();
		}
		else
		{
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "str1", str1 );
			pipelineCursor_1.destroy();
		}
		// pipeline
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void PrintFirstTenNaturalNumbers (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(PrintFirstTenNaturalNumbers)>> ---
		// @sigtype java 3.5
		// [o] field:1:required num
		int num =0;
		while(num<10)
		{
			// pipeline
		
			// pipeline
			IDataCursor pipelineCursor = pipeline.getCursor();
			IDataUtil.put( pipelineCursor, "num", num );
			pipelineCursor.destroy();
		
			num++;
			
		}
				
		
		// pipeline
		
		// pipeline
			
		// --- <<IS-END>> ---

                
	}



	public static final void StringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(StringList)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

