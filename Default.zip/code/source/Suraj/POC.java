package Suraj;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class POC

{
	// ---( internal utility methods )---

	final static POC _instance = new POC();

	static POC _newInstance() { return new POC(); }

	static POC _cast(Object o) { return (POC)o; }

	// ---( server methods )---




	public static final void Addition (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(Addition)>> ---
		// @sigtype java 3.5
		// [i] field:0:required a
		// [i] field:0:required b
		String a = IdataUtil.getString(pipelineCursor,"a");
		String b = IdataUtil.getString(pipelineCursor,"b");
		pipelineCursor.destroy();
		
		int s = Integer.parseInt(a) + Integer.parseInt(b);
		String out = s + "";
		// --- <<IS-END>> ---

                
	}
}

